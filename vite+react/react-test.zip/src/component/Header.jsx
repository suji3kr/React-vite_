const Header = () => {
  return (
    <header>
      <h1>🍫 Coffee ☕</h1>
    </header>
  );
};

export default Header;
