const Footer = () => {
    return (
      <div>
        <h1>⌯˃̶ᗜ˂̶⌯ಣ</h1>
      </div>
    );
  };
  
  export default Footer;